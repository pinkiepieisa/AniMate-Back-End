create function auditar_usuario() returns trigger
    language plpgsql
as
$$
BEGIN
  INSERT INTO Auditoria (tabela_afetada, id_registro, operacao)
  VALUES ('Usuario', OLD.id, TG_OP);
  RETURN OLD;
END;
$$;

alter function auditar_usuario() owner to admin;

