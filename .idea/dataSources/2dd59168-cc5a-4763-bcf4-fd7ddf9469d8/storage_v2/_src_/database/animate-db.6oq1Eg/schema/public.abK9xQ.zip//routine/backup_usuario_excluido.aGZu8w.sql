create function backup_usuario_excluido() returns trigger
    language plpgsql
as
$$
BEGIN
  INSERT INTO UsuarioExcluido (nome, email, cpf)
  VALUES (OLD.nome, OLD.email, OLD.cpf);
  RETURN OLD;
END;
$$;

alter function backup_usuario_excluido() owner to admin;

